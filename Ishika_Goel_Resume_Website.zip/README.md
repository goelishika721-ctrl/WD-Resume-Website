# Personal Resume Website

A CSS-enhanced personal resume website created for the Web Development module assessment.

## Files
- `index.html` — resume website structure and content
- `style.css` — complete CSS styling

## Before publishing
Replace the placeholder email and profile links in `index.html` with your own details.

## GitHub Pages
After uploading the files to a public GitHub repository:
Settings → Pages → Deploy from a branch → `main` → `/ (root)` → Save.
